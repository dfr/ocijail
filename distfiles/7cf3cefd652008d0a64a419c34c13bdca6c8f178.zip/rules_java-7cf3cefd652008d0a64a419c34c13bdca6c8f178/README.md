# rules_java
Java Rules for Bazel https://bazel.build.
