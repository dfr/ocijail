# CLI11 Meson test / example

Requirements: meson, ninja

## Build

```bash
meson build
ninja -C build
```
