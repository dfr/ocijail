int foo();
int bar();
int main() { return foo() + bar(); }
