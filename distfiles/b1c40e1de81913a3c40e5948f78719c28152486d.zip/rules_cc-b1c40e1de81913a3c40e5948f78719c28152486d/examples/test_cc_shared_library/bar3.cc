#include "examples/test_cc_shared_library/bar3.h"

int bar3() { return 42; }
