#include "examples/test_cc_shared_library/baz.h"

int baz() { return 42; }
